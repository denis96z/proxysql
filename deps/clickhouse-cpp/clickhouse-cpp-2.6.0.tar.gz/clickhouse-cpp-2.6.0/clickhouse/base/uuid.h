#pragma once

#include <cstdint>
#include <utility>

namespace clickhouse {

using UUID = std::pair<uint64_t, uint64_t>;

}
